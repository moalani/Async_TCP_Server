//
//  Socket_server_delegate.cpp
//  socket
//
//  Created by Mohammed Al Ani on 6/19/21.
//
#define _CRT_SECURE_NO_WARNINGS
#include <ctime>
#include <iostream>
#include <string>
#include <boost/bind/bind.hpp>
#include "Socket_server_delegate.h"

namespace nbs {

namespace util {

    std::string make_daytime_string()
    {
        using namespace std; // For time_t, time and ctime;
        time_t now = time(0);
        return ctime(&now);
    }
    

    void client::new_connection(const std::string& connection_id) {
    
    //_protocol = boost::asio::ip::tcp::v4();
    //_connection_id = connection_id;
    //start();
    //boost::system::error_code ec;
    //_socket.connect(boost::asio::ip::tcp::endpoint(boost::asio::ip::address::from_string(connection_id), _port));
    std::cout << "Connected! " << std::endl;
    /*boost::asio::async_read_until(_socket, _streambuf, '\n', [self = shared_from_this()](boost::system::error_code error, std::size_t bytes_transferred)
    {
        std::cout << std::istream(&self->_streambuf).rdbuf();
    });*/
}


void client::connection_closed(const std::string& connection_id) {
    _socket.close();
}

void client::data_received(const std::string& connection_id, const std::vector<std::uint8_t>& data) {
    std::cout << " data_received" << std::endl;
}


void client::error(const std::string& message, bool fatal) {
    std::cout << " error" << std::endl;
}
void client::start()
{
    //_message = make_daytime_string();
    boost::asio::async_read_until(_socket, _streambuf, '\n', [self = shared_from_this()](boost::system::error_code error, std::size_t bytes_transferred)
    {
        std::cout << std::istream(&self->_streambuf).rdbuf();
    });
    /*boost::asio::async_write(_socket, boost::asio::buffer(_message),
        boost::bind(&client::handle_write, shared_from_this(),
            boost::asio::placeholders::error,
            boost::asio::placeholders::bytes_transferred));*/
}



void client::handle_write(const boost::system::error_code& /*error*/,
    size_t /*bytes_transferred*/)
{
}

client::client(boost::asio::ip::tcp::socket&& socket)
    :_socket(std::move(socket))
{
}

//client::client()
//{

//}
//client::client(boost::asio::io_context& io_context) : _ioc(io_context), _socket(io_context) {}
/*tcp::socket& socket()
{
    return _socket;
}*/
// Socket_server
/*Socket_server::Socket_server() {
    std::cout << "Default constructor" << std::endl;
}*/
//std::shared_ptr<Socket_server_delegate> delegate,

}// util
}// nbs
