//
//  main.cpp
//  socket
//
//  Created by Mohammed Al Ani on 6/19/21.
//

#include <stdio.h>
#include <iostream>
#include "Socket_server.h"
//#include "Socket_server_delegate.h"

using namespace nbs;
using namespace util;

        int main() {
            try {
                boost::asio::io_context ioc1;
                //std::shared_ptr<client> foo = std::make_shared<client>();
                //foo->_port = 9090;

                //foo->_ioc
                Socket_server server(15001, ioc1);
                server.async_accept();
                ioc1.run();
            }
            catch (const std::exception& error) {
                std::cerr << error.what() << std::endl;
            }
            //boost::asio::io_service ioc;
            //boost::asio::ip::tcp::socket socket(ioc);
            //socket.connect(boost::asio::ip::tcp::endpoint(boost::asio::ip::address::from_string("127.0.0.1"), 1234));
            //std::shared_ptr<client> d1;
            //boost::asio::ip::tcp::socket x;
            //boost::asio::io_context ioc1;
            //std::shared_ptr<client> foo = std::make_shared<client>(ioc1);
            //foo->_port = 1234;
            /*try {
                foo->new_connection("0.0.0.0");
            }
            catch (const std::exception& error) {
                std::cerr << error.what() << std::endl;
            }*/
            //foo->_socket.connect(boost::asio::ip::tcp::endpoint(boost::asio::ip::address::from_string("127.0.0.1"), 1234));
            //foo->new_connection("127.0.0.1");
            //foo->new_connection("127.0.0.1");
            //client c1(ioc1);
            //Socket_server server(1234, foo);
            std::cout << "Socket " << std::endl;
            return 0;
        }
    //}
//}
/* }
namespace nbs {

    namespace util {

        using namespace std;

        int main() {
            try {
                std::shared_ptr<Socket_server_delegate> d1;
                //shared_ptr<Socket_server_delegate> d1(new Socket_server_delegate());
                //boost::asio::io_context io_context;
                Socket_server server(1234, d1);
                server.async_accept("connect_1");
                //tcp_server server(io_context);
            }
            catch (std::exception& e)
            {
                std::cerr << e.what() << std::endl;
            }


            cout << "Socket " << endl;
            return 0;
        }

    } // namespace util
} // namespace nbs
*/


/*

Q1: Socket_server implements Socket_server_delegate (inheritance)? Or define another class for implementing Socket_server_delegate?


*/

/*
NOTES:
The io_context class provides the core I/O functionality for users of the asynchronous I/O objects, including:

boost::asio::ip::tcp::socket
boost::asio::ip::tcp::acceptor
boost::asio::ip::udp::socket

acceptor: passive socket: it just waits for the other endpoint's socket to request for a connection, it is read-only
Socket is bound to the endpoint

*/