#pragma once

#include <cstdint>
#include <string>
#include <vector>
#include <optional>
#include "boost/asio.hpp"
#include "Socket_server_delegate.h"
#include <mutex>

namespace nbs
{

	namespace util
	{
		
		/// \brief Handles a simple TCP server
		class Socket_server
		{
		public:
			void async_accept();
			//void do_write(int length, const char* reply);
			//void do_read();

			//Socket_server();// = default;

			/// \brief Creates an asynchonous TCP server
			///
			/// The server operates asynchronously. This constructor returns immediately.
			///
			/// \param port The port number on which to listen for connections
			///
			/// \param delegate Interface called for certain events.
			///
			/// \throw std::exception Error setting up the server
			//std::shared_ptr<Socket_server_delegate> delegate,
			//, boost::asio::io_context& io_context
			// std::shared_ptr<client>& delegate,
			Socket_server(unsigned int port,  boost::asio::io_context& io_context);

			/// \brief The number of currently connected clients
			unsigned int connection_count();

			/// \brief Sends data to all connected clients
			///
			/// \param data The data
			void broadcast(const std::vector<std::uint8_t>& data);
			//void async_accept(const std::string& connection_id);
			//void data_received(const std::string& connection_id, const std::vector<std::uint8_t>& data);
			//void new_connection(const std::string& connection_id);
			//void connection_closed(const std::string& connection_id);
			//void error(const std::string& message, bool fatal);
			/// \brief Closes all connections and shuts down the server
			//void async_accept(std::shared_ptr<client>& delegate);
			~Socket_server() {};

			Socket_server(const Socket_server&) = delete;
			void operator=(const Socket_server&) = delete;
			//private:
			//void handle_accept(client::pointer new_connection,
			//	const boost::system::error_code& error);
			boost::asio::ip::tcp::acceptor _acceptor;
			std::optional<boost::asio::ip::tcp::socket> socket;
			//boost::asio::ip::tcp::socket _socket;
			//boost::asio::ip::tcp _protocol = boost::asio::ip::tcp::v4();;
			boost::system::error_code _ec;
			boost::asio::io_context& server_io_context;
			//std::vector<client> connected_clients;
			//static std::vector<Socket_server*> connected_clients;
			//boost::asio::streambuf _streambuf;
			unsigned int _port;
			
			//std::optional<boost::asio::ip::tcp::socket> socket;
		};


	} // namespace util

} // namespace nbs