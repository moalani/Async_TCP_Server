#include <iostream>
#include <string>
#include <boost/bind.hpp>
#include "Socket_server.h"

namespace nbs
{

	namespace util
	{
		//std::mutex mu;
		// server_ioc(delegate->_ioc),
		//std::vector<Socket_server*> Socket_server::connected_clients;
		// std::shared_ptr<client>& delegate,
		Socket_server::Socket_server(unsigned int port,  boost::asio::io_context& io_context) :
			server_io_context(io_context), _acceptor(io_context, boost::asio::ip::tcp::endpoint(boost::asio::ip::address::from_string("127.0.0.1"), port))
		{
			//tcp_connection* new_connection = new tcp_connection(io_service_);
			//acceptor_.async_accept(new_connection->socket(),
				//boost::bind(&tcp_server::start_accept, this, new_connection,
					//boost::asio::placeholders::error));
			//mu.lock();
			//connected_clients.push_back(this);
			//mu.unlock();
			// boost::asio::ip::address::from_string(connection_id)
			// boost::asio::ip::tcp::v4()
			//start_accept();
			//_acceptor = _acceptor(delegate->_ioc, boost::asio::ip::tcp::endpoint(boost::asio::ip::tcp::v4(), port));


			
		}
		//_acceptor(delegate->_ioc, boost::asio::ip::tcp::endpoint(boost::asio::ip::tcp::v4(), port))
		//_acceptor(_ioc, boost::asio::ip::tcp::endpoint(boost::asio::ip::tcp::v4(), port))
		//_socket.emplace(_ioc);
		//delegate->new_connection();
		//ep = boost::asio::ip::tcp::endpoint ep(boost::asio::ip::address_v4::any(),
		// 
		 //   port);
		//boost::asio::ip::tcp::acceptor acceptor(delegate->ios, delegate->protocol);
		//_acceptor = boost::asio::ip::tcp::acceptor(_ioc, delegate->_protocol);
		//delegate->_port = port;
		//delegate->_socket = boost::asio::ip::tcp::socket(_ioc);
		//delegate->_socket.open(delegate->_protocol, delegate->_ec);
		//_acceptor = boost::asio::ip::tcp::acceptor(delegate->_ioc, boost::asio::ip::tcp::v4(),port);
		//}
		// from https://www.boost.org/doc/libs/1_39_0/doc/html/boost_asio/reference/basic_socket_acceptor/async_accept/overload1.html
		/*void Socket_server::handle_accept(client::pointer new_connection,
			const boost::system::error_code& error)
		{
			if (!error)
			{
				new_connection->start();
			}

			async_accept();
		}*/
		/*void Socket_server::async_accept(std::shared_ptr<client>& delegate) {
			client::pointer new_connection =
				client::create(_ioc);
			socket.emplace(_ioc);
			_acceptor.async_accept(delegate->_socket, handle_accept);
			_acceptor.async_accept(*socket, [&](boost::system::error_code error) {
				std::cout << "async_accept -> " << error.message() << "\n";
				if (!error) {
					std::make_shared<client>(std::move(*socket))->new_connection(delegate->_connection_id);
					async_accept(delegate); // THIS LINE
				}
			});
		}*/
		void Socket_server::async_accept()
		{
			//client::pointer new_connection =
			//	client::create();
			//do_read();
			socket.emplace(server_io_context);
			std::cout << "Accepting new connections ..." << std::endl;
			_acceptor.async_accept(*socket, [&](boost::system::error_code error) {
				std::make_shared<client>(std::move(*socket))->start();
				async_accept();
				});
				//boost::bind(&Socket_server::handle_accept, this, new_connection,
				//	boost::asio::placeholders::error));
		}

		void Socket_server::broadcast(const std::vector<std::uint8_t>& data) {

		
		}

		//void Socket_server::async_accept(const std::string& connection_id)
		//{
			/*_socket.emplace(_ioc);

			_acceptor.async_accept(*socket, [&](boost::system::error_code error)
				{
					std::make_shared<Socket_server_delegate>(std::move(*socket))->new_connection(connection_id);
					async_accept(connection_id);
				});*/
				//}
	}
}